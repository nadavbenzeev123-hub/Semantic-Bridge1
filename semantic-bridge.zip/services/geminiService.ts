
import { GoogleGenAI, Type } from "@google/genai";
import { ValidationResult, GamePrompt } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateNewGame = async (): Promise<GamePrompt> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "Generate two completely unrelated nouns for a word association game. They should be from very different domains (e.g., 'Galaxy' and 'Toaster'). Return as JSON.",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          startWord: { type: Type.STRING },
          targetWord: { type: Type.STRING }
        },
        required: ["startWord", "targetWord"]
      }
    }
  });

  return JSON.parse(response.text) as GamePrompt;
};

export const validateStep = async (
  currentWord: string,
  userWord: string,
  targetWord: string
): Promise<ValidationResult> => {
  const prompt = `
    Context: A word association game.
    Current word: "${currentWord}"
    User's proposed next word: "${userWord}"
    Final target word: "${targetWord}"

    Task:
    1. Check if "${userWord}" is semantically related to "${currentWord}". 
    2. Check if "${userWord}" is semantically equivalent or identical to the target word "${targetWord}".
    
    Rules for relationship:
    - Must be a clear association (synonym, category, part-whole, strong contextual link).
    - Loose or abstract associations are allowed but should make sense.
    
    Return JSON:
    {
      "isRelated": boolean,
      "isTarget": boolean,
      "reason": "Short explanation of why it is or isn't related"
    }
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          isRelated: { type: Type.BOOLEAN },
          isTarget: { type: Type.BOOLEAN },
          reason: { type: Type.STRING }
        },
        required: ["isRelated", "isTarget", "reason"]
      }
    }
  });

  return JSON.parse(response.text) as ValidationResult;
};
