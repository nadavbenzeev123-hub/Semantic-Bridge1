
export interface GameSession {
  startWord: string;
  targetWord: string;
  history: string[];
  currentWord: string;
  steps: number;
  status: 'playing' | 'won' | 'loading' | 'idle';
}

export interface ValidationResult {
  isRelated: boolean;
  isTarget: boolean;
  reason: string;
}

export interface GamePrompt {
  startWord: string;
  targetWord: string;
}
