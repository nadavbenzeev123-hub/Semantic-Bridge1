
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameSession, ValidationResult } from './types';
import { generateNewGame, validateStep } from './services/geminiService';
import WordPath from './components/WordPath';

const App: React.FC = () => {
  const [game, setGame] = useState<GameSession>({
    startWord: '',
    targetWord: '',
    history: [],
    currentWord: '',
    steps: 0,
    status: 'idle'
  });
  const [userInput, setUserInput] = useState('');
  const [message, setMessage] = useState<{ text: string, type: 'error' | 'success' | 'info' | null }>({ text: '', type: null });
  const [isValidating, setIsValidating] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const startNewGame = async () => {
    setGame(prev => ({ ...prev, status: 'loading' }));
    setMessage({ text: 'Generating a new challenge...', type: 'info' });
    try {
      const { startWord, targetWord } = await generateNewGame();
      setGame({
        startWord,
        targetWord,
        history: [startWord],
        currentWord: startWord,
        steps: 0,
        status: 'playing'
      });
      setMessage({ text: '', type: null });
    } catch (err) {
      setMessage({ text: 'Failed to generate game. Please try again.', type: 'error' });
      setGame(prev => ({ ...prev, status: 'idle' }));
    }
  };

  useEffect(() => {
    startNewGame();
  }, []);

  const handleValidation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || game.status !== 'playing' || isValidating) return;

    const trimmedInput = userInput.trim().toLowerCase();
    
    // Prevent using the same word as current or in history
    if (game.history.some(h => h.toLowerCase() === trimmedInput)) {
      setMessage({ text: "You've already used that word!", type: 'error' });
      return;
    }

    setIsValidating(true);
    setMessage({ text: 'AI is thinking...', type: 'info' });

    try {
      const result: ValidationResult = await validateStep(game.currentWord, trimmedInput, game.targetWord);

      if (result.isTarget || trimmedInput === game.targetWord.toLowerCase()) {
        setGame(prev => ({
          ...prev,
          history: [...prev.history, trimmedInput, prev.targetWord],
          currentWord: prev.targetWord,
          steps: prev.steps + 1,
          status: 'won'
        }));
        setMessage({ text: `Success! You bridged the gap in ${game.steps + 1} steps!`, type: 'success' });
      } else if (result.isRelated) {
        setGame(prev => ({
          ...prev,
          history: [...prev.history, trimmedInput],
          currentWord: trimmedInput,
          steps: prev.steps + 1
        }));
        setMessage({ text: `Nice! ${result.reason}`, type: 'success' });
        setUserInput('');
      } else {
        setMessage({ text: `Rejected: ${result.reason}`, type: 'error' });
      }
    } catch (err) {
      setMessage({ text: 'Validation failed. Check your connection.', type: 'error' });
    } finally {
      setIsValidating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center py-12 px-4 selection:bg-indigo-500/30">
      {/* Header */}
      <header className="mb-12 text-center">
        <h1 className="text-5xl font-outfit font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-rose-400 mb-2">
          Semantic Bridge
        </h1>
        <p className="text-slate-400 max-w-md mx-auto">
          Bridge the gap between two distant concepts. Connect words by meaning.
        </p>
      </header>

      {/* Main Game Area */}
      {game.status === 'loading' ? (
        <div className="flex flex-col items-center justify-center space-y-4 h-64">
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-indigo-400 font-medium animate-pulse">Summoning the lexicon...</p>
        </div>
      ) : game.status === 'idle' ? (
        <button 
          onClick={startNewGame}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 px-10 rounded-2xl shadow-xl shadow-indigo-900/20 transition-all hover:scale-105"
        >
          Start New Game
        </button>
      ) : (
        <main className="w-full flex flex-col items-center max-w-4xl space-y-12">
          {/* Step Count */}
          <div className="flex items-center space-x-6">
            <div className="bg-slate-900/50 px-6 py-2 rounded-full border border-slate-800 backdrop-blur-sm">
              <span className="text-slate-500 text-xs uppercase tracking-widest mr-2 font-bold">Steps</span>
              <span className="text-2xl font-outfit font-bold text-white">{game.steps}</span>
            </div>
            {game.status === 'won' && (
              <button 
                onClick={startNewGame}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-6 rounded-full text-sm transition-all"
              >
                Play Again
              </button>
            )}
          </div>

          {/* Visualization */}
          <WordPath history={game.history} targetWord={game.targetWord} />

          {/* Controls */}
          {game.status === 'playing' && (
            <div className="w-full max-w-md sticky bottom-10 z-20">
              <form 
                onSubmit={handleValidation}
                className="bg-slate-900/80 backdrop-blur-xl p-4 rounded-3xl border border-slate-700 shadow-2xl flex flex-col space-y-3"
              >
                <div className="flex items-center space-x-3">
                  <input
                    ref={inputRef}
                    type="text"
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder={`Related to "${game.currentWord}"...`}
                    disabled={isValidating}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    autoFocus
                  />
                  <button
                    type="submit"
                    disabled={isValidating || !userInput.trim()}
                    className="bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-indigo-500 text-white font-bold px-6 py-3 rounded-xl transition-all"
                  >
                    {isValidating ? '...' : 'Bridge'}
                  </button>
                </div>
                
                {message.text && (
                  <div className={`text-sm px-2 font-medium transition-all ${
                    message.type === 'error' ? 'text-rose-400' : 
                    message.type === 'success' ? 'text-emerald-400' : 'text-indigo-400'
                  }`}>
                    {message.text}
                  </div>
                )}
              </form>
            </div>
          )}

          {game.status === 'won' && (
            <div className="animate-bounce bg-emerald-500/10 border border-emerald-500/30 px-8 py-4 rounded-2xl text-emerald-400 font-bold text-center">
              🎉 Bridge Complete! Amazing connection!
            </div>
          )}
        </main>
      )}

      {/* Footer Info */}
      <footer className="mt-auto pt-12 text-slate-600 text-[10px] uppercase tracking-widest text-center">
        Powered by Gemini 3 Flash • Built with React & Tailwind
      </footer>
    </div>
  );
};

export default App;
