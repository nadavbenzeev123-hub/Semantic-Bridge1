
import React from 'react';

interface WordPathProps {
  history: string[];
  targetWord: string;
}

const WordPath: React.FC<WordPathProps> = ({ history, targetWord }) => {
  return (
    <div className="flex flex-col items-center w-full max-w-2xl space-y-4 px-4 overflow-y-auto max-h-[50vh] py-6 scrollbar-hide">
      {history.map((word, index) => (
        <React.Fragment key={`${word}-${index}`}>
          <div 
            className={`
              relative px-8 py-3 rounded-2xl font-bold text-xl shadow-lg border-2 transition-all duration-500
              ${index === 0 ? 'bg-indigo-600 border-indigo-400 text-white' : 
                index === history.length - 1 ? 'bg-emerald-500 border-emerald-300 text-white animate-pulse scale-105' : 
                'bg-slate-800 border-slate-700 text-slate-300'}
            `}
          >
            {word.toUpperCase()}
            {index === 0 && <span className="absolute -top-3 left-2 bg-indigo-400 text-[10px] px-2 py-0.5 rounded-full uppercase tracking-tighter">Start</span>}
          </div>
          {index < history.length - 1 && (
            <div className="w-1 h-8 bg-gradient-to-b from-slate-700 to-slate-800 rounded-full" />
          )}
        </React.Fragment>
      ))}
      
      {/* Connector to target */}
      <div className="w-1 h-12 border-l-2 border-dashed border-slate-600 rounded-full" />
      
      <div className="px-8 py-4 rounded-2xl bg-slate-900 border-2 border-rose-500/50 text-rose-400 font-extrabold text-2xl shadow-[0_0_20px_rgba(244,63,94,0.2)]">
        {targetWord.toUpperCase()}
        <span className="absolute -bottom-3 right-2 bg-rose-500 text-white text-[10px] px-2 py-0.5 rounded-full uppercase tracking-tighter">Target</span>
      </div>
    </div>
  );
};

export default WordPath;
